/*
 * Copyright 2005-2017 ptnetwork.net. All rights reserved.
 * Support: http://www.ptnetwork.net
 * License: http://www.ptnetwork.net/license
 */
package net.ptnetwork.job;

import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

/**
 * Job - 购物车
 *
 * @author PTNETWORK Team
 * @version 5.0
 */
@Lazy(false)
@Component
public class CartJob {

}